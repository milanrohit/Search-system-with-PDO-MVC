<?php
include_once("Config/connection.php");

// Debugging functions
function _d($arr) {
    echo "<pre>";
    print_r($arr);
    echo "</pre>";
}

function _dx($arr) {
    echo "<pre>";
    print_r($arr);
    echo "</pre>";
    exit;
}

// Convert array to object
function arrayToObject($array) {
    $object = new stdClass();
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            $value = arrayToObject($value);
        }
        $object->$key = $value;
    }
    return $object;
}

// Convert object to array
function objectToArray($object) {
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    if (is_array($object)) {
        return array_map('objectToArray', $object);
    } else {
        return $object;
    }
}

// Return PDO fetch associative constant
function arrayinassocitive() {
    return PDO::FETCH_ASSOC;
}

?>