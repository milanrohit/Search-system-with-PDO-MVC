
<?php

// db.php

function getPDOConnection() {

  $host = 'localhost';
  $db = 'phpsearch';
  $user = 'root';
  $pass = '';
  $charset = 'utf8mb4';
  $pdo;

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $username = $user;
    $password = '';
    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
        exit;
    }
}
?>
