<?php
session_start();

include_once("Config/connection.php");
include_once("lib/libfunction.php");

class UserDetails {

    public function getAllUserDetails() {

        $pdo = getPDOConnection(); // connection

        // Generate a CSRF token if not already set
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF token validation
            if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
                die('CSRF token validation failed');
            }
        
            // Validate and sanitize input
            $input = filter_input(INPUT_POST, 'input', FILTER_SANITIZE_STRING);

            if (isset($_POST['input']) && $_POST['input'] != '') {
                $input = $_POST['input'];
                $query = "SELECT * FROM userdetails 
                          WHERE uname LIKE :input 
                          OR uage LIKE :input 
                          OR ucountry LIKE :input 
                          OR occupation LIKE :input";
                $stmt = $pdo->prepare($query);
                $input = $input . '%';
                $stmt->bindParam(':input', $input, PDO::PARAM_STR);
                $stmt->execute();
                $userDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
                return $userDetails;
            }
            return [];
        }
    }
}

$userDetails = new UserDetails();
$userDetails->getAllUserDetails();
?>