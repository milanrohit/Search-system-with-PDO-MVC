<?php
   include_once("Config/connection.php");
   include_once("lib/libfunction.php");
   include_once("Model/userDetails.cls.php");

    $userDetails = new userDetails();
    $userDetails = $userDetails->getalluserdetails();
    
    if(count($userDetails) > 0 )
    {
        ?>
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>uid</th>
                    <th>uname</th>
                    <th>uage</th>
                    <th>ucountry</th>
                    <th>uemail</th>
                    <th>occupation</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($userDetails as $k => $val){ ?>
                <tr>
                    <td><?php echo $val['uid']; ?> </td>
                    <td><?php echo $val['uname']; ?> </td>
                    <td><?php echo $val['uage']; ?> </td>
                    <td><?php echo $val['ucountry']; ?> </td>
                    <td><?php echo $val['uemail']; ?> </td>
                    <td><?php echo $val['occupation']; ?> </td>
                </tr>
            <?php   }  ?>
            </tbody>
        </table>
        <?php
    }else{
        echo "<h6 class='text -danger text-center mt-3'>No data found</h6>";
    }
?>