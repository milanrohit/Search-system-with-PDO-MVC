<?php 
// Start session
session_start();

    include_once("Config/connection.php");
    include_once("lib/libfunction.php");

// Generate a CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
}
?>

<!doctype html>
<html>
    <head>
        <title>Live Search</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    </head>
    <body>
        <div class="container" style="max-width: 50%;">
            <div class="text-center mt-4 mb-4">
                <h2>PDO MySQL Live Search</h2>
            </div>
            <input type="text" class="form-control" id="live_search" autocomplete="on" placeholder="Search ...">
        </div>

        <div id="searchresult"> </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#live_search").keyup(function() {
                    let input = $(this).val();

                    let csrfToken = $('meta[name="csrf-token"]').attr('content');
                    
                    if (input !== "") {
                        $.ajax({
                            url: "livesearch.php",
                            method: "POST",
                            data: { input: input, _: new Date().getTime() , csrf_token: csrfToken},
                            success: function(data) {
                                console.log(csrfToken);
                                $("#searchresult").html(data).show();
                            },
                            error: function(xhr, status, error) {
                                console.error("Error: " + error);
                                $("#searchresult").html('<p>An error occurred. Please try again later.</p>').show();
                            }
                        });
                    } else {
                        $("#searchresult").hide();
                    }
                });
            });
        </script>
    </body>
</html>